class ChannelExistsError(Exception):
    pass
class BotAdminError(Exception):
    pass
class ChannelLimitError(Exception):
    pass